Attention All Students:
There are only 3 files in this kit:

- Instructions file: ACS19E2 - Final Exam - Practical Component Instructions.pdf
- Exam Code: EXAM_CODE.txt
- This file: README.txt

The practical exam requires that you create the files from scratch.